package com.example.tripa;

import java.util.ArrayList;

public class APIPOJO {
    String status;
    ArrayList<Listlass> predictions;



}
